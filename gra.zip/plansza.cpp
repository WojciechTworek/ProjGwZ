#include "plansza.h"

Plansza::Plansza()
{

}
