#ifndef PLANSZA_H
#define PLANSZA_H


class Plansza
{
public:
    Plansza();
};

#endif // PLANSZA_H
